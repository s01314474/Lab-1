import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        System.out.println("Unsorted Array ---------------------------------------------------");
        ArrayList<Integer> integerList = Lab4.getList();
        if (integerList.isEmpty()) {
            System.out.println("The list is empty. Please check the 'integers.txt' file.");
            return;
        }
        Lab4.outputList(integerList);

        System.out.println("\n\nBubble sort results ----------------------------------------------");
        ArrayList<Integer> bubbleSortedList = new ArrayList<>(integerList);
        long bubbleStartTime = System.nanoTime();
        Lab4.bubbleSort(bubbleSortedList);
        long bubbleEndTime = System.nanoTime();
        Lab4.outputList(bubbleSortedList);
        System.out.printf("\nTime taken for Bubble Sort: %.3f ms%n", (bubbleEndTime - bubbleStartTime) / 1_000_000.0);

        System.out.println("\n\nInsertion sort results -------------------------------------------");
        ArrayList<Integer> insertionSortedList = new ArrayList<>(integerList);
        long insertionStartTime = System.nanoTime();
        Lab4.insertionSort(insertionSortedList);
        long insertionEndTime = System.nanoTime();
        Lab4.outputList(insertionSortedList);
        System.out.printf("\nTime taken for Insertion Sort: %.3f ms%n", (insertionEndTime - insertionStartTime) / 1_000_000.0);
    }
}

class Lab4 {
    // Implements insertion sort algorithm
    public static void insertionSort(ArrayList<Integer> integerList) {
        for (int i = 1; i < integerList.size(); i++) {
            int key = integerList.get(i);
            int j = i - 1;

            while (j >= 0 && integerList.get(j) > key) {
                integerList.set(j + 1, integerList.get(j));
                j--;
            }
            integerList.set(j + 1, key);
        }
    }

    // Implements bubble sort algorithm
    public static void bubbleSort(ArrayList<Integer> integerList) {
        int n = integerList.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (integerList.get(j) > integerList.get(j + 1)) {
                    // Swap elements
                    int temp = integerList.get(j);
                    integerList.set(j, integerList.get(j + 1));
                    integerList.set(j + 1, temp);
                }
            }
        }
    }

    // Reads integers from a file named "integers.txt" and returns them as a list
    public static ArrayList<Integer> getList() {
        ArrayList<Integer> integerList = new ArrayList<>();
        String line;
        try (BufferedReader br = new BufferedReader(new FileReader("integers.txt"))) {
            while ((line = br.readLine()) != null) {
                try {
                    integerList.add(Integer.parseInt(line.trim()));
                } catch (NumberFormatException e) {
                    System.err.println("Invalid integer in file: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
        return integerList;
    }

    // Outputs the list of integers
    public static void outputList(ArrayList<Integer> integerList) {
        for (int i = 0; i < integerList.size(); i++) {
            System.out.print(integerList.get(i) + " ");
        }
        System.out.println();
    }
}
